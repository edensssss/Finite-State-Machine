import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import ac.il.afeka.Submission.Submission;
import ac.il.afeka.fsm.Alphabet;
import ac.il.afeka.fsm.DFSM;
import ac.il.afeka.fsm.State;

public class Main implements Submission, Assignment1 {

	@Override
	public List<String> submittingStudentIds() {
		return Arrays.asList("315685461", "314864018");
	}

	@Override
	public boolean compute(String dfsmEncoding, String input) throws Exception {

		DFSM dfsm = new DFSM(dfsmEncoding);
		return dfsm.compute(input);

	}

	public static void main(String[] args) throws Exception {

		String input = "bbba";
		String dfsmEncoding = "0 1/a b/0 , a , 0; 0,b, 1 ;1, a, 0 ; 1, b, 1/0/ 1\n";

		System.out.println(new Main().compute(dfsmEncoding, input));

	}

}
